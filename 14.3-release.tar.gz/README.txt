This 14.3 release supports the ZC702 and ZC706 boards from Xilinx.
The files for each board are contained in the respective directories.
Copy the files from the directory to the root directory of a FAT formatted
SD card, then set the board to boot from SD and boot Linux.
